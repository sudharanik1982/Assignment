package com.crossover.e2e;

import java.io.File;
import java.io.FileReader;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import junit.framework.TestCase;

import org.apache.commons.lang3.RandomStringUtils;
import org.junit.Test;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class GMailTest extends TestCase {
	private WebDriver driver;
	private Properties properties = new Properties();

	public void setUp() throws Exception {
		// Initialize Chrome Driver
		System.setProperty("webdriver.chrome.driver", ".//Resources//chromedriver.exe");
		driver = new ChromeDriver();
		// Read Test Properties
		properties.load(new FileReader(new File("test.properties")));
	}

	public void tearDown() throws Exception {
		// Quit Browser
		driver.quit();
	}

	@Test
	public void testSendEmail() throws Exception {
		// Maximize Browser window
		driver.manage().window().maximize();
		// Launch gmail homepage
		driver.get("https://mail.google.com/");
		// Enter Username & Password and login
		WebElement userElement = driver.findElement(By.id("identifierId"));
		userElement.sendKeys(properties.getProperty("username"));
		driver.findElement(By.id("identifierNext")).click();
		System.out.println("1. Entered the user name");
		WebElement passwordElement = driver.findElement(By.name("password"));
		WebDriverWait wait = new WebDriverWait(driver, 20);
		wait.until(ExpectedConditions.elementToBeClickable(passwordElement));
		passwordElement.sendKeys(properties.getProperty("password"));
		driver.findElement(By.id("passwordNext")).click();
		System.out.println("2. Entered the password and click on login");
		driver.findElement(By.cssSelector(".aic .z0 div")).click();

		// Verify login
		driver.findElement(By.xpath("//*[starts-with(@name,'to')]"))
				.sendKeys(properties.getProperty("username") + "@gmail.com");

		// Variables for email subject and content
		String strRandomString = RandomStringUtils.randomAlphabetic(8);
		String subject = "GmailTestScript" + strRandomString;
		String body = "Assignment Task";
		driver.findElement(By.xpath("//*[starts-with(@name,'subjectbox')]")).sendKeys(subject);
		driver.findElement(By.cssSelector(".Am.Al.editable.LW-avf")).sendKeys(body);

		// select More Options and select Social label and send email
		WebElement moreoptions = driver.findElement(By.cssSelector("div[data-tooltip='More options']"));
		moreoptions.click();
		driver.manage().timeouts().implicitlyWait(8, TimeUnit.SECONDS);
		WebElement label = driver.findElement(By.cssSelector("span[class='J-Ph-hFsbo']"));
		String javaScript = "var evObj = document.createEvent('MouseEvents');"
				+ "evObj.initMouseEvent(\"mouseover\",true, false, window, 0, 0, 0, 0, 0, false, false, false, false, 0, null);"
				+ "arguments[0].dispatchEvent(evObj);";
		((JavascriptExecutor) driver).executeScript(javaScript, label);
		driver.findElement(By.cssSelector("input[class='bqf']")).sendKeys("social");
		driver.manage().timeouts().implicitlyWait(8, TimeUnit.SECONDS);
		driver.findElement(By.cssSelector("div[title='Social']")).click();
		driver.manage().timeouts().implicitlyWait(8, TimeUnit.SECONDS);
		driver.findElement(By.cssSelector(".T-I.J-J5-Ji.aoO.T-I-atl.L3")).click();
		System.out.println("3. Sent an Email with Unique Subject and marked the lable as Social");

		// Select Social tab and search for given subject of the email and select first
		// email from the list
		driver.findElement(By.cssSelector("td[class*='aRz'] div[aria-label='Social']")).click();
		System.out.println("4. Navigated to Social Tab");

		WebElement searchElement = driver.findElement(By.name("q"));
		searchElement.sendKeys(subject);
		searchElement.sendKeys(Keys.ENTER);
		System.out.println("5. Searched with the keyword as Email Subject");

		WebElement sentEmailElement = driver
				.findElement(By.cssSelector("div[class='ae4 UI'] div[class='Cp'] div table tbody tr"));
		sentEmailElement.click();
		System.out.println("6. Found the Email matches matches with the searched Email Subject");

		// Select Star
		WebElement starElement = driver.findElement(By.cssSelector("span[class='T-KT']"));
		starElement.click();
		Thread.sleep(10000);
		System.out.println("7. Email Marked as Starred");

		// Verify subject and body of the selected email
		String SubjectofEmail = driver.findElement(By.cssSelector("h2[class='hP']")).getText();
		String BodyOfEmail = driver.findElement(By.cssSelector("div[class*='a3s'] div[dir='ltr']")).getText();
		if (BodyOfEmail.equalsIgnoreCase(body) && SubjectofEmail.equalsIgnoreCase(SubjectofEmail)) {
			System.out.println("8. Body of the email verified");
			System.out.println("Test script pass");
		} else {
			System.out.println("Body Info of the email is mismatched");
			System.out.println("Test script Failed");
		}
	}
}
